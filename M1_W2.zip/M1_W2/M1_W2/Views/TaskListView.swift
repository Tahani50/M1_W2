//
//  HomeView.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

struct TaskListView: View {
    
    // Access the shared TaskModelView using @EnvironmentObject
    @EnvironmentObject var viewModel: TaskModelView
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in // Allows dynamic layout adjustments
                ScrollView { // Enables vertical scrolling for tasks
                    LazyVStack { // Optimized list
                        ForEach(viewModel.items) { item in // Loops through all tasks
                            HStack {
                                // Navigation link to open the TaskDetailView when tapped
                                NavigationLink(destination: TaskDetailView(item: item)) {
                                    TaskRowView(item: item, viewModel: viewModel)
                                        .padding()
                                        .frame(maxWidth: geometry.size.width * 0.9) // Responsive width
                                        .background(item.color)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .shadow(radius: 5) 
                                        .transition(.opacity.combined(with: .scale)) // Smooth appearance transition
                                        .animation(.easeInOut, value: viewModel.items) // Animates task list changes
                                }
                                
                                // Button to delete a task
                                Button(action: {
                                    withAnimation {
                                        viewModel.deleteTaskById(item) // Deletes the selected task
                                    }
                                }) {
                                    Image(systemName: "trash") // Trash icon
                                        .foregroundColor(.red) // Makes the icon red for visibility
                                }
                            }
                        }
                    }
                    .padding() // Adds spacing around the list
                }
            }
            .navigationTitle("To-Do List") // Sets the screen title
            .toolbar {
                // Add task button (top-right corner)
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink(destination: TaskAddView()) {
                        Label("New", systemImage: "plus") // "+" icon for adding tasks
                    }
                }
                
                // Filter tasks alphabetically button (top-left corner)
                ToolbarItem(placement: .topBarLeading) {
                    Button("Filter") {
                        withAnimation {
                            viewModel.filterTasksAlphabetically() // Toggles alphabetical sorting
                        }
                    }
                }
            }
        }
    }
}


