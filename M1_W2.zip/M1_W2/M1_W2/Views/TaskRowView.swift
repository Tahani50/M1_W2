//
//  TDLIRow.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

struct TaskRowView: View {
    
    // The task item to be displayed in the row
    var item: Task
    
    // Environment property to detect the current color scheme (light or dark mode)
    @Environment(\.colorScheme) var colorScheme
    
    // Access the shared TaskModelView 
    var viewModel: TaskModelView
    
    var body: some View {
        HStack {
            // VStack to organize task title and due date
            VStack(alignment: .leading, spacing: 8) {
                // Task title
                Text(item.title)
                    .font(.headline)
                    .foregroundColor(colorScheme == .dark ? .white : .black) // Adjusts text color for dark/light mode
                
                // Task due date formatted in a user-friendly way
                Text("\(Date(timeIntervalSince1970: item.dueDate).formatted(date: .abbreviated, time: .shortened))")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            // Button to toggle task completion
            Button(action: {
                withAnimation {
                    viewModel.toggleTaskCompletion(item)
                }
            }) {
                Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle") // Uses different icons for completed/incomplete tasks
                    .foregroundColor(item.isCompleted ? Color("Color1") : .gray) // Changes color based on completion status
                    .imageScale(.large) // Makes the icon slightly larger
            }
        }
        .padding() // Adds padding around the row
        .background(item.color) // Sets the task's assigned color as background
        .cornerRadius(10) // Rounds the corners of the row
        .transition(.opacity.combined(with: .scale)) // Smooth transition when appearing/disappearing
    }
}


