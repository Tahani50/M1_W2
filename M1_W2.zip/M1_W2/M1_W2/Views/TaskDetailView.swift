//
//  ToDoListDetailView.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

struct TaskDetailView: View {
    
    // The task item whose details will be displayed
    let item: Task
    
    // Detects the current color scheme (light or dark mode)
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background color using the task's assigned color
                Color(item.color)
                    .ignoresSafeArea() // Extends the color to cover the entire screen
                
                VStack(spacing: 25) {
                    // Section for displaying the task's due date
                    Section(header: Text("Due Date: ")) {
                        Text("\(Date(timeIntervalSince1970: item.dueDate).formatted(date: .abbreviated, time: .shortened))")
                            .bold() // Makes the due date text bold
                    }
                    
                    // Section for displaying the task description
                    Section(header: Text("Description:")) {
                        Text(item.description)
                            .bold() // Makes the description text bold
                            .multilineTextAlignment(.center) // Aligns text to center
                    }
                    
                    Spacer()
                }
                .navigationTitle(item.title) // Sets the navigation bar title to the task title
                .frame(width: 330, height: 410) // Fixed size for the content box
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(colorScheme == .dark ? Color.black.opacity(0.8) : Color.white) // Background color adapts to dark/light mode
                )
                .shadow(radius: 5) // Adds a shadow effect
            }
        }
    }
}

