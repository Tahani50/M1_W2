//
//  ToDoListAddView.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

struct TaskAddView: View {
    
    // Access the shared TaskModelView using @EnvironmentObject
    @EnvironmentObject var viewModel: TaskModelView
    
    // Environment property to dismiss the view when needed
    @Environment(\.dismiss) private var dismiss
    
    // State variables to store user input for a new task
    @State var title = "" // Task title
    @State var description = "" // Task description
    @State var dueDate = Date() // Task due date (default: current date)
    @State var isCompleted = false // Task completion status (default: false)
    @State var color = Color(.blue.opacity(0.2)) // Default task color with transparency
    
    var body: some View {
        NavigationStack {
            VStack {
                // Form container for structured input fields
                Form {
                    // Text field for entering the task title
                    TextField("Title", text: $title)
                        .textFieldStyle(DefaultTextFieldStyle())

                    // Text field for entering the task description
                    TextField("Description", text: $description)
                        .textFieldStyle(DefaultTextFieldStyle())

                    // Date picker for selecting the due date of the task
                    DatePicker("Due Date", selection: $dueDate)
                        .datePickerStyle(GraphicalDatePickerStyle())

                    // Color picker for selecting a task color
                    ColorPicker("Color", selection: $color)

                    // Custom button to add a new task and dismiss the view
                    CustomButton(title: "Add", background: Color("Color1")) {
                        viewModel.addTask(title: title, description: description, dueDate: dueDate.timeIntervalSince1970, color: color)
                        dismiss()
                    }
                }
            }
            .navigationTitle("Add To-Do") // Sets the navigation title
        }
    }
}

