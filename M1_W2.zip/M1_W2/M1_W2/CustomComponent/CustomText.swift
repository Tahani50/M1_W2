//
//  CustomText.swift
//  M1_W2
//
//  Created by Tahani Ayman on 17/09/1446 AH.
//

import SwiftUI

// A reusable custom text component using @ViewBuilder
@ViewBuilder
func customText(_ text: String, font: Font, color: Color) -> some View {
    Text(text) // Displays the given text
        .font(font) // Applies the specified font style
        .foregroundColor(color) // Sets the text color
}
