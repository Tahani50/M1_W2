//
//  CustomButton.swift
//  M1_W2
//
//  Created by Tahani Ayman on 16/09/1446 AH.
//

import SwiftUI

struct CustomButton: View {
    
    let title: String // The text displayed on the button
    let background: Color // The background color of the button
    let action: () -> Void // The action to be executed when the button is tapped

    var body: some View {
        Button {
            action() // Executes the provided action when the button is tapped
        } label: {
            ZStack {
                // Background shape with rounded corners
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(background) // Sets the background color
                
                // Button title text
                Text(title)
                    .foregroundColor(.white) // White text color
                    .bold() // Makes the text bold
            }
        }
        .padding() // Adds padding around the button 
    }
}


