//
//  ContentView.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        // TabView to provide a tab-based navigation interface
        TabView {
            // First tab: Displays TaskListView
            TaskListView()
                .tabItem {
                    Label("Home", systemImage: "house") // Tab label with icon
                }
    
            // Second tab: Displays SettingsView
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "person.circle") // Tab label with icon
            }
        }
    }
}
