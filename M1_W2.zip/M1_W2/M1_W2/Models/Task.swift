//
//  ToDoListItem.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

// MARK: - Task Model
struct Task: Identifiable, Equatable {
    let id = UUID()
    var title: String
    var description: String
    var dueDate: TimeInterval
    var isCompleted: Bool
    let color: Color
}

