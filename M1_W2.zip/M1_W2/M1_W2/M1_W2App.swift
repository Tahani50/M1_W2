//
//  M1_W2App.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

@main
struct M1_W2App: App {
    @StateObject var viewModel = TaskModelView()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
