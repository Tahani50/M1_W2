//
//  ToDoListModelView.swift
//  M1_W2
//
//  Created by Tahani Ayman on 15/09/1446 AH.
//

import SwiftUI

// ViewModel class that manages the task list and interactions
class TaskModelView: ObservableObject {
    
    // Tracks whether tasks should be sorted alphabetically
    @Published var isFilteredAlphabetically = false
    
    // List of tasks, stored as an array of Task objects
    @Published var items = [
        Task(
            title: "Buy Groceries",
            description: "Purchase vegetables, fruits, and dairy products.",
            dueDate: Date().addingTimeInterval(86400).timeIntervalSince1970, // 1 day from now
            isCompleted: false,
            color: .blue.opacity(0.2)
        ),
        Task(
            title: "Workout",
            description: "Go for a morning run and do strength training.",
            dueDate: Date().addingTimeInterval(43200).timeIntervalSince1970, // 12 hours from now
            isCompleted: false,
            color: .green.opacity(0.2)
        ),
        Task(
            title: "Read Book",
            description: "Read 30 pages of 'Atomic Habits'.",
            dueDate: Date().addingTimeInterval(72000).timeIntervalSince1970, // 20 hours from now
            isCompleted: false,
            color: .orange.opacity(0.2)
        ),
        Task(
            title: "Call Mom",
            description: "Check in with Mom and catch up on family updates.",
            dueDate: Date().addingTimeInterval(3600).timeIntervalSince1970, // 1 hour from now
            isCompleted: false,
            color: .purple.opacity(0.2)
        )
    ]
    
    // MARK: - Task Actions
    
    // Toggles the completion status of a task.
    func toggleTaskCompletion(_ item: Task) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            withAnimation {
                items[index].isCompleted.toggle() // Toggle completion status
            }
        }
    }
    
    // Adds a new task to the task list.
    func addTask(title: String, description: String, dueDate: TimeInterval, color: Color) {
        let newTask = Task(
            title: title,
            description: description,
            dueDate: dueDate,
            isCompleted: false,
            color: color
        )
        
        withAnimation {
            items.append(newTask) // Append the new task to the list
        }
    }
    
    // Deletes a task from the list by its ID.
    func deleteTaskById(_ item: Task) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            withAnimation {
                items.remove(at: index) // Remove the task
            }
        }
    }
    
    // Filters tasks alphabetically. If already sorted, shuffles them back.
    func filterTasksAlphabetically() {
        withAnimation {
            isFilteredAlphabetically.toggle()
            if isFilteredAlphabetically {
                items.sort { $0.title.lowercased() < $1.title.lowercased() } // Sort alphabetically
            } else {
                items.shuffle() // Shuffle to undo sorting
            }
        }
    }
}
